Tarea5LP

========

Alumnos:

	José Miguel Castro Opazo		201273514-9
	Marco Antonio Salinas Carrasco		201273589-0

========

Personajes creados:
	theViper: D = 40, V = 40, F = 20, W = baston, A = armadura_ligera.
	theMountain: D = 30, V = 10, F = 60, W = espada_larga, A = armadura_completa.

La pelea:
	?- pelea(theViper, theMountain, Winner).